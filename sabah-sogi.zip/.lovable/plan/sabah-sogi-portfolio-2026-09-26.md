# Sabah Sogi Portfolio

## Build
- Create a single editorial portfolio with a sticky desktop navigation and compact mobile menu.
- Make the home page work-first: concise introduction, filterable selected work, capabilities, personal process, experience, about, and contact.
- Add a dedicated `/work` browse page and reusable `/work/$slug` case-study pages.
- Use a restrained neutral palette, a single warm purple accent, strong editorial type, generous whitespace, square media framing, and restrained motion.

## Work and media
- Store all projects in a typed data file, using only the supplied project areas and verified proof points.
- Label missing assets clearly as `[MEDIA TO ADD]`; do not fabricate names, visuals, results, or links.
- Support images, local or hosted video, galleries, and optional original social links through reusable media components.
- Include documented media URL helpers and environment placeholders so hosted storage URLs can be added later without changing page components.

## Quality checks
- Add unique metadata for home, work, and case-study pages.
- Verify filtering, navigation, case-study opening, responsive layouts, keyboard focus, video fallback behavior, and missing-media states.
- Check the preview at desktop and mobile sizes and resolve build or runtime errors.

## Technical notes
- Keep the existing TanStack Start and Tailwind v4 setup.
- Use route files for `/`, `/work`, and `/work/$slug`; do not create company- or role-specific variants.
- Keep all color and typography choices in semantic design tokens.
