# Portfolio Content, Project Structure, and Media Repair

## Exact content corrections

- Re-audit every project against `PROJECT_1_pasted.md` and replace shortened, rewritten, missing, or invented copy with the supplied wording and section order.
- Remove “Thinking, making, and everything between.” from Selected Work.
- Rename the Events project to exactly “Google for India”.
- Remove “Making Online Safety Feel Human” and the combined Trust & Safety framing.
- Apply the supplied contact heading, email, LinkedIn URL, coffee/chai line, and clickable phone number.
- Preserve explicit omissions: no unsupported metrics, AI Mode, Search Easter Egg, or sections the document says to remove.

## Individual project structure

- Convert Google Doodles (Search) from one combined entry into three independent cards and detail pages:
  - Independence Day - Textiles of India
  - Celebrating KK
  - Celebrating Hamida Banu
- Make each Doodle title link to its supplied official Google Doodles page.
- Convert Trust & Safety from one combined entry into three independent cards and detail pages:
  - Raho Do Kadam Aagey
  - Scam Pehchano, Mauka Ganwao
  - Always-on Trust & Safety
- Keep each project’s own Brief, Insight, Idea, What I Did, supporting sections, and Media only where explicitly supplied.

## Supplied assets

- Add the attached Fund My Crazy MP4 only to the Fund My Crazy page as a directly playable video with controls.
- Replace the Festive Moments thumbnail with attachment 2.
- Use attachments 3–5 only for the three Doodle cards and their matching detail pages.
- Use attachment 6 only for Scam Pehchano, Mauka Ganwao.
- Use attachment 7 only for Always-on Trust & Safety.
- Keep the already-correct Raho Do Kadam Aagey thumbnail.
- Store each uploaded binary once as a hosted asset and reference it without duplication.

## Media repair

- Replace empty placeholder blobs for Instagram items with responsive embedded posts, each paired with a direct “View original post ↗” fallback.
- Show YouTube items as playable on-page videos with direct-link fallbacks.
- Show the supplied local MP4 through the existing native video treatment.
- Keep LinkedIn media viewable through a labeled linked preview and direct fallback because LinkedIn does not provide a reliable public embed for this post type.
- Keep every media item on its specified project page, in the supplied order, without generic galleries or duplicated media.
- Keep the Leslee Lewis organic mention and its media separate and directly after the supplied statement.

## Verification

- Check all five filters and confirm the Doodles and Trust & Safety tabs each show exactly three independent cards.
- Open every project page and compare all visible copy and section ordering against the supplied document.
- Verify all uploaded thumbnails, the Fund My Crazy video, Instagram embeds, YouTube players, LinkedIn fallback, and original links on desktop and mobile.
- Confirm unique metadata for every content page and no build, runtime, hydration, or broken-media errors.
