# Events Content and Structure Update

## Content changes

- Keep the existing visual identity and overall layout unchanged.
- Reduce the work filter strip to Events, Product / Feature Launches, Culture, Google Doodles (Search), and Trust & Safety, in that order.
- Remove the How I Work, Experience, and About sections. Keep Contact as the final home-page section.
- Replace the current project list with the two supplied Events projects, using only the provided copy, responsibilities, and Instagram links.
- Remove this **"Strategy is only interesting when it becomes something"**

## Project presentation

- Keep the existing project pages, but present them as work rather than “case studies.”
- Use Brief as the introduction, followed by Insight, Idea, What I Did, On-ground and Creator Amplification where supplied.
- Keep thumbnails as the primary media and pair each future thumbnail with its corresponding Instagram URL.
- Present Instagram evidence at a constrained, responsive size with a “View original post ↗” fallback link.
- Do not add metric cards, fabricated performance figures, stock imagery, generated imagery, or content for the four unpopulated categories.

## Verification

- Confirm the category order, both Events projects, removed sections, Contact ending, project navigation, Instagram links, and desktop/mobile presentation.
- Confirm every content page retains unique metadata and the preview has no build or runtime errors.