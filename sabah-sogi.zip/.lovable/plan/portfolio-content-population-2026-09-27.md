# Portfolio Content Population

## Scope

- Keep the current typography, spacing, colors, navigation behavior, project cards, media treatment, and page structure unchanged.
- Preserve the approved hero structure while updating its sentence exactly as supplied.
- Keep Contact as the final home-page section and retain only Work, About, and Contact in site navigation.

## Work structure

- Keep the five existing work categories in this order: Events, Product / Feature Launches, Culture, Google Doodles (Search), and Trust & Safety.
- Expand the project data source with the supplied projects and subsections, using only the provided facts, copy, responsibilities, and links.
- Support project-specific content shapes so concise projects, grouped cultural work, and multi-part Doodle or Trust & Safety work do not become an artificial identical template.
- Keep every project shareable through the existing `/work/$slug` pages with unique metadata.

## Media behavior

- Use the existing project media and placeholder treatment; do not introduce a new gallery or embed design.
- Render each media item once as a linked thumbnail with its original URL and a `View original post ↗` fallback.
- Keep the two supplied Events thumbnails already in place and show labeled placeholders for media whose thumbnails have not yet been supplied.
- Do not download videos, generate imagery, embed large social posts, or duplicate media.

## Content safeguards

- Exclude AI Mode, Pop Culture, Search Easter Egg, Products Meet Culture, the 98% sentiment metric, and any unsupported claims or results.
- Treat Festive Moments and Language + Local Culture as curated bodies of work, and preserve the supplied subsection structure for Doodles and Trust & Safety.
- Keep the Leslee Lewis mention explicitly organic, not a partnership.
- Avoid the term “case study” and avoid em dashes in newly added copy.

## Verification

- Check all five filters, every new work page, links, one-time media rendering, home-page section order, and unique page metadata.
- Verify desktop and mobile layouts, then confirm the preview has no build or runtime errors.
