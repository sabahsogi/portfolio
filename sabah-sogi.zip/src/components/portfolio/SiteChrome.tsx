import { useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const links = [
  { label: "Work", href: "/#work" },
  { label: "Contact", href: "/#contact" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  return (
    <header className="site-header">
      <div className="site-shell grid grid-cols-[minmax(0,1fr)_auto] items-center py-4">
        <Link to="/" className="font-display text-lg font-semibold">Sabah Sogi<span className="text-primary">.</span></Link>
        <nav className="hidden items-center gap-7 text-sm md:flex" aria-label="Primary navigation">
          {pathname === "/" ? links.map((link) => <a key={link.label} className="nav-link" href={link.href}>{link.label}</a>) : <><Link className="nav-link" to="/work">Work</Link><Link className="nav-link" to="/">Home</Link></>}
        </nav>
        <Button className="md:hidden" variant="ghost" size="icon" onClick={() => setOpen((value) => !value)} aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open}>
          {open ? <X /> : <Menu />}
        </Button>
      </div>
      {open && <nav className="site-shell border-t border-border py-5 md:hidden" aria-label="Mobile navigation">
        <div className="grid gap-4 text-lg">
          {links.map((link) => <a key={link.label} href={link.href} onClick={() => setOpen(false)}>{link.label}</a>)}
        </div>
      </nav>}
    </header>
  );
}

export function Footer() {
  return <footer className="border-t border-border py-7"><div className="site-shell flex flex-wrap justify-between gap-3 text-xs text-muted-foreground"><span>Sabah Sogi · Bangalore</span><span>Brand, social & content</span></div></footer>;
}
