import { ImageIcon } from "lucide-react";
import type { ProjectMedia } from "@/data/projects";
import { cn } from "@/lib/utils";

type Props = { media: ProjectMedia; accent?: string; className?: string | undefined };

export function MediaFrame({ media, accent = "violet", className }: Props) {
  if (media.kind === "image" && media.src) {
    return <img className={cn("h-full w-full object-cover", className)} src={media.src} alt={media.alt} loading="lazy" />;
  }
  if (media.kind === "video" && media.src) {
    return <VideoCard media={media} className={className} />;
  }
  return (
    <div className={cn("media-placeholder", `media-${accent}`, className)} role="img" aria-label={media.alt}>
      <div className="media-placeholder-inner">
        <ImageIcon aria-hidden="true" />
        <span>[MEDIA TO ADD]</span>
      </div>
    </div>
  );
}

export function VideoCard({ media, className }: { media: ProjectMedia; className?: string | undefined }) {
  if (!media.src) return <MediaFrame media={{ kind: "placeholder", alt: media.alt }} className={className} />;
  return (
    <div className={cn("relative h-full w-full overflow-hidden bg-ink", className)}>
      <video className="h-full w-full object-cover" src={media.src} poster={media.poster} controls playsInline preload="metadata">
        Your browser does not support this video.
      </video>
    </div>
  );
}
