import { ArrowDown, ArrowRight } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { projects } from "@/data/projects";
import { ProjectGrid } from "./ProjectGrid";

export function Hero() {
  return <section className="site-shell hero-grid pt-14 pb-20 md:pt-24 md:pb-28">
    <div>
      <p className="eyebrow">{`\n\n\n`}</p>
      <h1 className="mt-5 font-display text-5xl font-semibold leading-none md:text-7xl lg:text-8xl">Hi, I’m Sabah<span className="text-primary">.</span></h1>
      <p className="mt-7 max-w-3xl text-xl leading-relaxed md:text-2xl">I work across brand, social and content — turning products, ideas, cultural moments, shower thoughts, conversations and intentionally bad puns into things people actually want to engage with.</p>
      <p className="mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg">6+ years across agency and in-house, most recently shaping editorial and social strategy for Google India.</p>
      <div className="mt-6 border-l-2 border-primary pl-5 text-sm leading-relaxed text-muted-foreground md:text-base">
        <p>Idea bank? Concept deck? Scripts? Content calendars? Brand playbooks, GTMs? Hotel? Trivago.<br /><br />Basically I.. like making things.</p>
      </div>
      <div className="mt-8 flex flex-wrap gap-3"><Button size="lg" asChild><a href="#work">See the work <ArrowDown /></a></Button><Button size="lg" variant="outline" asChild><a href="#contact">Get in touch</a></Button></div>
    </div>
  </section>;
}

export function SelectedWork() {
  return <section id="work" className="section-block bg-surface"><div className="site-shell"><div className="section-heading"><p className="eyebrow">Selected work</p><Button asChild variant="outline"><Link to="/work">View all work <ArrowRight /></Link></Button></div><ProjectGrid projects={projects} /></div></section>;
}

export function Contact() {
  return <section id="contact" className="section-block bg-primary text-primary-foreground"><div className="site-shell"><p className="eyebrow text-primary-foreground/70">Contact</p><h2 className="mt-5 max-w-4xl font-display text-5xl font-semibold leading-none md:text-7xl">Let’s chat soon?</h2><div className="mt-12 flex flex-wrap gap-3"><Button variant="secondary" size="lg" asChild><a href="mailto:sabahsogi98@hotmail.com">Email <ArrowRight /></a></Button><Button variant="accentOutline" size="lg" asChild><a href="https://www.linkedin.com/in/sabah-sogi/">LinkedIn <ArrowRight /></a></Button></div><p className="mt-8 text-base text-primary-foreground/80">Even better if you'd like to chat over coffee or chai:</p><a className="mt-2 inline-block text-lg font-semibold underline underline-offset-4" href="tel:+919620071229">+91 96200 71229</a></div></section>;
}
