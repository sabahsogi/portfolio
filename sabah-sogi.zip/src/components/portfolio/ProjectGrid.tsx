import { useState } from "react";
import { ArrowUpRight } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { projectFilters, type Project, type ProjectFilter } from "@/data/projects";
import { MediaFrame } from "./MediaFrame";

export function ProjectFilters({ active, onChange }: { active: ProjectFilter; onChange: (filter: ProjectFilter) => void }) {
  return (
    <div className="scrollbar-none -mx-5 flex gap-2 overflow-x-auto px-5 pb-1 md:mx-0 md:flex-wrap md:px-0" aria-label="Filter projects">
      {projectFilters.map((filter) => (
        <Button key={filter} variant={active === filter ? "default" : "outline"} size="sm" onClick={() => onChange(filter)} aria-pressed={active === filter}>
          {filter}
        </Button>
      ))}
    </div>
  );
}

export function ProjectCard({ project, priority = false }: { project: Project; priority?: boolean }) {
  return (
    <Link to="/work/$slug" params={{ slug: project.slug }} className="project-card group block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
      <div className="project-media">
        <MediaFrame media={project.thumbnail} accent={project.accent} />
        <span className="project-arrow"><ArrowUpRight aria-hidden="true" /></span>
      </div>
      <div className="pt-4">
        <div className="mb-2 flex items-center justify-between gap-4 text-xs uppercase text-muted-foreground">
          <span>{project.category}</span>
        </div>
        <h3 className="font-display text-2xl font-semibold leading-tight md:text-3xl">{project.title}</h3>
        <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground md:text-base">{project.description}</p>
        <div className="mt-4 flex flex-wrap gap-x-3 gap-y-1 text-xs font-medium text-primary">
          {project.tags.map((tag) => <span key={tag}>{tag}</span>)}
        </div>
      </div>
    </Link>
  );
}

export function ProjectGrid({ projects, showFilters = true }: { projects: Project[]; showFilters?: boolean }) {
  const [active, setActive] = useState<ProjectFilter>("Events");
  const visible = projects.filter((project) => project.category === active);
  return (
    <div>
      {showFilters && <div className="mb-9"><ProjectFilters active={active} onChange={setActive} /></div>}
      <div className="grid gap-x-6 gap-y-12 md:grid-cols-2 lg:gap-x-8 lg:gap-y-16">
        {visible.map((project, index) => <ProjectCard key={project.slug} project={project} priority={index < 2} />)}
      </div>
    </div>
  );
}
