/**
 * Portfolio media can be a local `/portfolio/...` path or a public hosted URL.
 * Suggested hosted structure: portfolio/images, portfolio/videos, portfolio/projects.
 * Add URLs in src/data/projects.ts; components require no changes.
 */
export const mediaConfig = {
  serviceUrl: import.meta.env["VITE_SUPABASE_URL"] ?? "",
  publicKey: import.meta.env["VITE_SUPABASE_ANON_KEY"] ?? "",
  localBase: "/portfolio",
};
