import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowUpRight, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MediaFrame } from "@/components/portfolio/MediaFrame";
import { getProject, type ProjectEvidence } from "@/data/projects";

export const Route = createFileRoute("/work/$slug")({
  loader: ({ params }) => {
    const project = getProject(params.slug);
    if (!project) throw notFound();
    return project;
  },
  head: ({ loaderData, params }) => {
    const title = loaderData ? `${loaderData.title} | Sabah Sogi` : "Work not found | Sabah Sogi";
    const description = loaderData?.description ?? "Selected work by Sabah Sogi.";
    return { meta: [{ title }, { name: "description", content: description }, { property: "og:title", content: title }, { property: "og:description", content: description }, { property: "og:type", content: "article" }, { property: "og:url", content: `/work/${params.slug}` }, { name: "twitter:card", content: "summary_large_image" }], links: [{ rel: "canonical", href: `/work/${params.slug}` }] };
  },
  component: ProjectPage,
});

function Detail({ label, paragraphs }: { label: string; paragraphs: string[] }) {
  return <section className="case-detail"><p className="eyebrow">{label}</p><div className="case-copy">{paragraphs.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}</div></section>;
}

function instagramEmbedUrl(url: string) {
  const match = url.match(/instagram\.com\/(p|reel)\/([^/?]+)/);
  return match ? `https://www.instagram.com/${match[1]}/${match[2]}/embed/captioned/` : undefined;
}

function youtubeEmbedUrl(url: string) {
  const parsed = new URL(url);
  const id = parsed.hostname === "youtu.be" ? parsed.pathname.slice(1) : parsed.searchParams.get("v");
  return id ? `https://www.youtube-nocookie.com/embed/${id}` : undefined;
}

function EvidenceItem({ item }: { item: ProjectEvidence }) {
  if (item.media) {
    const frame = <div className={item.media.kind === "video" ? "mx-auto aspect-[9/16] w-full max-w-sm overflow-hidden bg-ink" : "overflow-hidden"}><MediaFrame media={item.media} /></div>;
    return <article className="evidence-item">
      {item.note && <p className="mb-4 max-w-2xl text-base leading-relaxed text-muted-foreground">{item.note}</p>}
      {item.originalUrl ? <a href={item.originalUrl} target="_blank" rel="noreferrer" className="block transition-opacity hover:opacity-90">{frame}</a> : frame}
      <div className="mt-3 flex items-start justify-between gap-4"><p className="text-sm text-muted-foreground">{item.label}</p>{item.originalUrl && <a className="evidence-link" href={item.originalUrl} target="_blank" rel="noreferrer">View original post ↗</a>}</div>
    </article>;
  }

  const url = item.originalUrl;
  if (!url) return null;
  const isInstagram = url.includes("instagram.com/");
  const isYouTube = url.includes("youtube.com/") || url.includes("youtu.be/");
  const embedUrl = isInstagram ? instagramEmbedUrl(url) : isYouTube ? youtubeEmbedUrl(url) : undefined;

  return <article className="evidence-item">
    {item.note && <p className="mb-4 max-w-2xl text-base leading-relaxed text-muted-foreground">{item.note}</p>}
    {embedUrl ? (
      <iframe
        className={isInstagram ? "social-embed social-embed-instagram" : "social-embed social-embed-youtube"}
        src={embedUrl}
        title={item.label}
        loading="lazy"
        allow={isYouTube ? "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" : undefined}
        allowFullScreen={isYouTube}
      />
    ) : (
      <a className="linked-media" href={url} target="_blank" rel="noreferrer"><ExternalLink aria-hidden="true" /><span>{item.label}</span></a>
    )}
    <div className="mt-3 flex items-start justify-between gap-4"><p className="text-sm text-muted-foreground">{item.label}</p><a className="evidence-link" href={url} target="_blank" rel="noreferrer">View original post ↗</a></div>
  </article>;
}

function MediaItems({ items }: { items: ProjectEvidence[] }) {
  return <div className="evidence-grid mt-7">{items.map((item, index) => <EvidenceItem item={item} key={`${item.originalUrl ?? item.label}-${index}`} />)}</div>;
}

function ProjectPage() {
  const project = Route.useLoaderData();
  return <article>
    <header className="site-shell py-10 md:py-16">
      <Link to="/work" className="back-link"><ArrowLeft /> All work</Link>
      <div className="mt-10 grid gap-8 md:grid-cols-[1.35fr_.65fr]">
        <div><p className="eyebrow">{project.brand} · {project.category}</p>{project.titleUrl ? <a className="group/title inline-flex items-start gap-3" href={project.titleUrl} target="_blank" rel="noreferrer"><h1 className="mt-5 max-w-4xl font-display text-5xl font-semibold leading-none group-hover/title:underline md:text-7xl">{project.title}</h1><ExternalLink className="mt-7 h-5 w-5 shrink-0" aria-hidden="true" /></a> : <h1 className="mt-5 max-w-4xl font-display text-5xl font-semibold leading-none md:text-7xl">{project.title}</h1>}{project.subtitle && <p className="mt-4 text-xl text-muted-foreground">{project.subtitle}</p>}{project.tags.length > 0 && <div className="mt-5 flex flex-wrap gap-x-3 gap-y-1 text-xs font-medium text-primary">{project.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>}</div>
        {project.role && <dl className="case-meta"><div><dt>Role</dt><dd>{project.role}</dd></div></dl>}
      </div>
    </header>
    <div className="site-shell"><div className="aspect-[16/9] overflow-hidden"><MediaFrame media={project.thumbnail} accent={project.accent} /></div></div>
    <div className="site-shell case-layout">
      <div>{project.brief && <Detail label="Brief" paragraphs={project.brief} />}{project.insight && <Detail label="Insight" paragraphs={project.insight} />}{project.idea && <Detail label="Idea" paragraphs={project.idea} />}</div>
      <div>{project.contributions && <section className="case-detail"><p className="eyebrow">What I did</p><div className="case-copy">{project.contributionIntro && <p>{project.contributionIntro}</p>}<ul>{project.contributions.map((item) => <li key={item}>{item}</li>)}</ul></div></section>}{project.onGround && <Detail label="On-ground" paragraphs={project.onGround} />}{project.creatorAmplification && <Detail label="Creator Amplification" paragraphs={project.creatorAmplification} />}</div>
    </div>
    {project.evidence.length > 0 && <section className="site-shell pb-20" aria-labelledby="project-media"><p className="eyebrow" id="project-media">Media</p><MediaItems items={project.evidence} /></section>}
    <div className="border-t border-border py-12"><div className="site-shell"><Button asChild><Link to="/work">More work <ArrowUpRight /></Link></Button></div></div>
  </article>;
}
