import { createFileRoute } from "@tanstack/react-router";
import { Contact, Hero, SelectedWork } from "@/components/portfolio/HomeSections";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sabah Sogi | Brand, Social & Content" },
      { name: "description", content: "Portfolio of Sabah Sogi, a brand, social and content marketer with 6+ years across agency and in-house marketing, most recently with Google India." },
      { property: "og:title", content: "Sabah Sogi | Brand, Social & Content" },
      { property: "og:description", content: "Brand, social and content work across strategy, culture, products, creators and campaigns." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Index,
});

function Index() {
  return <><Hero /><SelectedWork /><Contact /></>;
}
