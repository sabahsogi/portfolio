import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { ProjectGrid } from "@/components/portfolio/ProjectGrid";
import { projects } from "@/data/projects";

export const Route = createFileRoute("/work/")({
  head: () => ({
    meta: [
      { title: "Selected Work | Sabah Sogi" },
      { name: "description", content: "Selected brand, social, content, cultural, creator and product storytelling work by Sabah Sogi." },
      { property: "og:title", content: "Selected Work | Sabah Sogi" },
      { property: "og:description", content: "Brand, social and content work across strategy, culture, products, creators and campaigns." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/work" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/work" }],
  }),
  component: WorkPage,
});

function WorkPage() {
  return <div className="site-shell py-14 md:py-24"><Link to="/" className="back-link"><ArrowLeft /> Home</Link><div className="mb-12 mt-10 md:mb-16"><p className="eyebrow">Selected work</p></div><ProjectGrid projects={projects} /></div>;
}